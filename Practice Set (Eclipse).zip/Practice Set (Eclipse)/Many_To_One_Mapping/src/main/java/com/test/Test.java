package com.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
        Transaction transaction=session.beginTransaction();

        Employee emp= new Employee();
        emp.setName("Anil");
        emp.setEmail("anil123@gmail.com");
        emp.setSalary("50000");
        
        Employee emp1= new Employee();
        emp1.setName("Gopal");
        emp1.setEmail("gopal123@gmail.com");
        emp1.setSalary("60000");
        
        Address address = new Address();
        address.setCity("Pune");
        address.setPincode("411036");
        address.setState("Maharashtra");
        address.setCountry("India");
        
        emp.setAddress(address);
        emp1.setAddress(address);
        
        session.save(emp);
        session.save(emp1);
        
        transaction.commit();
        session.close();
        sf.close();
	}

}
