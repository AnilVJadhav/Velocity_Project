package com.test;

import java.io.Serializable;

public class Demo implements Serializable, Cloneable {
	
	//create static Ref
	static Demo demo;
	
	//Create private Constructor
	private Demo() {
		
	}
      public static Demo getDemoObject() {
    	  synchronized (Demo.class) {
    		  
    		  if(demo==null) {
    			  
    			  demo 	= new Demo();
    		  }
    		  else {
    			  
    			  return demo;
    		  }
			return demo;
		}
      }
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
      
	  protected Object readResolve() {
		  return demo;
	  }
}
