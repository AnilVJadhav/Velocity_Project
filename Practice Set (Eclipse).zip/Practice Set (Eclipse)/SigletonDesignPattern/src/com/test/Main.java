package com.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		//writting the object into file 
		Demo demo = Demo.getDemoObject();
		FileOutputStream fos=new FileOutputStream("C:\\Users\\Shree\\Desktop\\Demo.txt");
		ObjectOutputStream out = new ObjectOutputStream(fos);
        out.writeObject(demo);
        System.out.println("Writting the Object into Stream");
        
        //reading file object 
        ObjectInputStream ois= new ObjectInputStream(new FileInputStream("C:\\Users\\Shree\\Desktop\\Demo.txt"));
        Demo demo1= (Demo) ois.readObject();
        System.out.println("reading the Object from file");
        
        System.out.println("Hashcode of demo:"+demo.hashCode());
        System.out.println("Hashcode of emo1:"+demo1.hashCode());
	} 

}
