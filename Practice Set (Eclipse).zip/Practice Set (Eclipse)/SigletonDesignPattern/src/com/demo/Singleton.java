package com.demo;

public class Singleton {
	
	//Creating Ref variable of singleton class
	private static Singleton singletonObjRef;
	
	//Making Constructor private 
	private Singleton()
	{
		
	}
	//create static  method which will return Singleton class Object
    public static Singleton getSingletonObject()
    {
    	//Number of line of code 
    	
    	synchronized (Singleton.class) {
    		if(singletonObjRef==null) {
    			singletonObjRef = new Singleton();	
    		}else {
    			return singletonObjRef;
    		}
    		
        	return singletonObjRef;
		}
    }
}
