package com.demo;

public class SingletoneClone implements Cloneable{

	//create static instance of singleton class
		 private static SingletoneClone singletonClone;
		
		//create private Constructor
		private SingletoneClone()
		{
			
		}
		//create static  method which will return SingletonClone class Object
		public static SingletoneClone getSingletonCloneClassObject() {
			
			synchronized (Singleton.class) {
		    if(singletonClone==null){
		    	
			singletonClone = new SingletoneClone();
			
		} else{
			
			return singletonClone;
		}
			return singletonClone;
	  }	
    }
		@Override
		protected Object clone() throws CloneNotSupportedException {
			throw new CloneNotSupportedException("Clone cannot create");

		}
		
		
}


