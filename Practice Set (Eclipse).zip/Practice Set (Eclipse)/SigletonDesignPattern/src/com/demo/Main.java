package com.demo;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		
		SingletoneClone obj1= SingletoneClone.getSingletonCloneClassObject();
		SingletoneClone obj2= (SingletoneClone) obj1.clone();

		System.out.println("obj1 class object Hashcode is:"+obj1.hashCode());
        System.out.println("obj2 class Object Hashcode is:"+obj2.hashCode());
	}

}
