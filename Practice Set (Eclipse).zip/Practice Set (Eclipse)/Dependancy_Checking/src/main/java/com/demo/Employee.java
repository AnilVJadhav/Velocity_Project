package com.demo;

public class Employee {
	
	private String FirstName;
	private Address address;
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
		
	}
        @Override
	public String toString() {
		return "Employee [FirstName=" + FirstName + ", address=" + address + "]";
	}
        
		public void getEmpDetails() {
			
        	System.out.println("Emp details are :"+FirstName);
        	System.out.println("Address is:"+address);
        }
}
