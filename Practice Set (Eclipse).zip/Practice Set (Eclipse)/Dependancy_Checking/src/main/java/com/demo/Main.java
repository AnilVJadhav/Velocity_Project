package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		//Create Object Of ApplicationContex
		ApplicationContext contex =new ClassPathXmlApplicationContext("Spring.xml");
		Employee emp =(Employee) contex.getBean("employee");
		System.out.println("Employee details:"+emp);
		emp.getEmpDetails();
	}

}
