package com.demo;

public class Address {
	
	    private String AddressLine;
		private String city;
		private String Pincode;
		
		
		public String getAddressLine() {
			return AddressLine;
		}
		public void setAddressLine(String addressLine) {
			AddressLine = addressLine;
		}
		public String getCity() {	
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getPincode() {
			return Pincode;
		}
		public void setPincode(String pincode) {
			Pincode = pincode;
		}
		@Override
		public String toString() {
			return "Address [AddressLine=" + AddressLine + ", city=" + city + ", Pincode=" + Pincode + "]";
		}


}
