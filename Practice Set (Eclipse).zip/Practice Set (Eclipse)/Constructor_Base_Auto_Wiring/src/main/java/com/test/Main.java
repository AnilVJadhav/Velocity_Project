package com.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {

	public static void main(String[] args) {
		//Create Object of BeanFactory
		Resource resource =new ClassPathResource("spring.auto.xml");
		BeanFactory beanFactory= new XmlBeanFactory(resource);
		Categories categories=(Categories) beanFactory.getBean("categories");
		categories.show();
	}

}
