package com.java.mini.project.quiz;
	import java.util.Scanner;

import com.java.mini.project.quiz.exam.Exam;

	public class Login {
		
	  	Exam exam= new Exam();
	
		  public static void main(String[] args) {
			
			System.out.println("*****Welcome to Quiz Competetion*****");
			System.out.println("Signup to take the quiz");

			Login login=new Login();
			login.signUp();
		}
		  
		public void signUp()
		{
			SignUpLogin sul=new SignUpLogin();
			
	         Scanner sc=new Scanner(System.in);
	         System.out.println("Set Username : ") ; 
	         String uName=sc.nextLine();
	         sul.setUsername(uName);
	         
	         System.out.println("Set Password : ");
	         String uPassword=sc.nextLine();
	         sul.setPassword(uPassword);
	 
	         while(true) {
	    	  int temp=0;
	      System.out.println("Enter Username : ");
	      String user=sc.nextLine();
	     
	      System.out.println("Enter Password : ");
	      String pwd=sc.nextLine();
	      
	      if(user.equals(sul.getUsername()))
	      {
	       if(pwd.equals(sul.getPassword()))
	       {
	    	   System.out.println("Logged Inn Successfully!!");
	    	   System.out.println("Please check your correct username and password ");
	    	   
	    	   if(temp==0) {
	    		   temp++;
	       }
	      }
	        	System.out.println("Enter the next Quetion");
	        	exam.randomFetchData();
         
		}
}
		}
	}