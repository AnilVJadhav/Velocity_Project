package com.java.mini.project.quiz.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Exam {
	
	 Scanner scan = new Scanner(System.in);
      int count =0;
	
	public void randomFetchData() {
		try {
			
			//Loading Class
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish connection
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz", "root", "Anilj@1998");
			 System.out.println("Enter your Choice quetion");
			int no=scan.nextInt();
			  
			//create preparedstatement
			PreparedStatement preparedstatement=connection.prepareStatement("Select*from exam where Question_No=?");
			
		    preparedstatement.setInt(1, no);
			
		ResultSet rs=preparedstatement.executeQuery();
		System.out.println("**************************");
		
		while(rs.next()) {
		
			
			System.out.println(rs.getString("Questions"));
			System.out.println(rs.getString("Option_1"));
			System.out.println(rs.getString("Option_2"));
			System.out.println(rs.getString("Option_3"));
			System.out.println(rs.getString("Option_4"));	
			
			System.out.println("Enter your answer");
			String ans= scan.next();
			if(ans.equals(rs.getString("Correct_answer"))){
				System.out.println("Correct");
			}else {
				System.out.println("Wrong");
			}
	      }
		
	   }       catch (Exception e) {
			e.printStackTrace();
		}

	}

}
