package com.Comparable.Example;

import java.util.ArrayList;
import java.util.Collections;

public class Test {

	public static void main(String[] args) {
		
		ArrayList<Student> al= new ArrayList<Student>();
		al.add(new Student (4, "Ram", 90));
		al.add(new Student (5, "anil" , 100));
		al.add(new Student (6, "sohel", 400));
		al.add(new Student (9, "yash", 20));

		Collections.sort(al);
		
		al.forEach(a->System.out.println(a.getRollno()+ " "+ a.getName()+ " "+a.getMarks()));
	}
}
