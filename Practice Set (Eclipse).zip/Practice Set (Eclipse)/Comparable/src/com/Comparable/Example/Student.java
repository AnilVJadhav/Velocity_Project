package com.Comparable.Example;

public class Student implements Comparable <Student>{

	private int Rollno;
	private String name;
	private int marks;
	public int getRollno() {
		return Rollno;
	}
	public void setRollno(int rollno) {
		Rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
		@Override
	public String toString() {
		return "Student [Rollno=" + Rollno + ", name=" + name + ", marks=" + marks + "]";
	}
	public Student(int rollno, String name, int marks) {
		super();
		Rollno = rollno;
		this.name = name;
		this.marks = marks;
	}
	@Override
	public int compareTo(Student o) {
		if(name==o.getName())
		return 0;
		else if (name.equals(o.getName()))
			return 1;
		else
			return -1;
	}

	


}
