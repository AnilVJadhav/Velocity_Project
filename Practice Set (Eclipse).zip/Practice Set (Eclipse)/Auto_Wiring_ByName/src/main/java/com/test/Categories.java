package com.test;

public class Categories {
	
	private String name;
	//auto-wiring of policy pojo
	private Policy policy;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Policy getPolicy() {
		return policy;
	}
	public void setPolicy(Policy policy) {
		this.policy = policy;
	}
	@Override
	public String toString() {
		return "Categories [name=" + name + ", policy=" + policy + "]";
	}
	
	public void show() {
		
		System.out.println("Category name is:" +name);
		System.out.println("Policy name is :" +policy.getPlanName());
		System.out.println("Policy plan Amount is :" +policy.getPlanAmount()); 
	}

}
