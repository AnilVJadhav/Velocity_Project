package com.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {

	public static void main(String[] args) {
		
		//Create Object of BeanFactory 
		Resource resource =new ClassPathResource("spring.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		Categories catageries= (Categories) factory.getBean("categories");
		System.out.println("Category Object is "+catageries);
		catageries.show();

	}

}
