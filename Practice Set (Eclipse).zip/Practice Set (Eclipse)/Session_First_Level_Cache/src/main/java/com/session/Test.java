package com.session;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		//Step-1 Create Configuration Object
		Configuration configuration= new Configuration();
		
		//Step-2 Configure the Configuration
		configuration.configure("hibernate.cfg.xml");
		
		//Step-3 Create SessionFactory Object
		SessionFactory sf= configuration.buildSessionFactory();
		
		//Step-4 Create Object Of Session
	   Session session =sf.openSession();
	   
	   //Step-5 Retrieve the Single Object from Database
	  Student s= session.get(Student.class, 1);
	  System.out.println("Student id is :"+s.getId());
	  System.out.println("Student city is:"+s.getCity());
	  System.out.println("Student mobile is:"+s.getMobile());
	  System.out.println("Student name is:"+s.getName());
	  
	  System.out.println("*****************************************");
	  
	  Student s1=session.get(Student.class, 3);
	  System.out.println("Student id is :"+s1.getId());
	  System.out.println("Student city is :"+s1.getCity());
	  System.out.println("Student mobile is :"+s1.getMobile());
	  System.out.println("Sudent name is : "+s1.getName());
	  
	  session.close();
	}
}
