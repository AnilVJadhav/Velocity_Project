package com.Java.Map;

import java.util.HashMap;
import java.util.Map;

public class Example_1 {
	public static void main(String[] args) {
		
		HashMap hashmap=new HashMap();
		hashmap.put(10, "Anil");
		hashmap.put(11, "Ajay");
		hashmap.put(20, "Shital");
		
		System.out.println("HashMap contains :"+hashmap);
		
		
		
		Map map= new HashMap();
		map.put("Monday", 10.00);
		map.put("Tuesday",20.00);
		map.put("Friyday", 05.00);
		
		System.out.println("map contains :" +map);
	    System.out.println("Monday key havaing value: "+ map.get("Monday"));
	
		
		
	}

}
