package com.Java.Map;

import java.util.HashMap;
import java.util.Set;

public class Example_2 {

	public static void main(String[] args) {
		
		HashMap<Integer, String> hashmap=new HashMap<Integer, String>();
		hashmap.put(10, "Yogesh");
		hashmap.put(20, "Ajay");
		hashmap.put(30, "Swati");
		
		String name= hashmap.get(20);
		System.out.println("20 Contains :"+hashmap.get(20));
		
		Set<Integer>s=hashmap.keySet();
		
		for(int i:s) {
			System.out.println("key := "+i);
			System.out.println("Value := "+hashmap.get(i));
			
		}

	}

}
