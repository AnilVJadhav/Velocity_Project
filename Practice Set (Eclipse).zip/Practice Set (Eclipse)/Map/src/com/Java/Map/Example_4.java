package com.Java.Map;

import java.util.HashMap;

public class Example_4 {
	public static void main(String[] args) {
		HashMap hashamp= new HashMap();
		hashamp.put("A", 20);
		hashamp.put("B", 30);
		hashamp.put("C", 40);
		hashamp.put(null, 50);
		hashamp.put(null,null);
		hashamp.put(null, "D");
		
		System.out.println("Null values : "+hashamp);
		
		
		
	}

}
