package com.comparator.example;

import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		
		TreeSet treeset= new TreeSet(new Test());
		treeset.add(30);
		treeset.add(50);
		treeset.add(40);
		treeset.add(60);
		treeset.add(10);
		//treeset.add("Java");
		
		System.out.println(treeset);
		
		
		

	}

}
