package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Demo extends HttpServlet {
	private static final long serialVersionUID = 1L;

       public Demo() {
    	   System.out.println("Inside the Costructor of Demo servlet");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Inside the Init method of Demo servlet");
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

		protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			System.out.println("Inside the Service method");
			PrintWriter out =response.getWriter();
			out.print("<h1>This is My First Servlet Page...</h1>");
			
	}

}
