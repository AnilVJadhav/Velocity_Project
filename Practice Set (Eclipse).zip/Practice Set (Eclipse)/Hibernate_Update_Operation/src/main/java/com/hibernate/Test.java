package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		//Step-1 Create Object Of Configuration File
		Configuration cfg = new Configuration();
		
		//Step-2 configure with Configuration file
		cfg.configure("hibernate.cfg.xml");
		
		//Step-3 Creating the Object Of SessionFactory
		SessionFactory sf= cfg.buildSessionFactory();
		
		//Step-4 Create Session Object
		Session session= sf.openSession();
		
		//Step-5 Creating Transaction Object
		Transaction transaction=session.beginTransaction();
	
		//Step-6 Create the Object of Student Class
		Student student=session.get(Student.class, 4);
		System.out.println("Before Update the mobile number :"+student.getMobile());
		
		//Step-7 update mob num
		student.setMobile("9313308220");
		
		//Step-8 updating Mobile Number
		session.update(student);
		System.out.println("Mobile Number Updated Successfully...");
		
		transaction.commit();
		session.close();
    }
}