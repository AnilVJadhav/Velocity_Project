package com.java.gihub.project.example;

import java.util.ArrayList;

public class Demo4 {

	public static void main(String[] args) {
		
		ArrayList al= new ArrayList();
		al.add("Gopal");
		al.add("Anil");
		al.add("Shiva");
		al.add("Prasad");
		
		System.out.println(al);
		

	}

}
