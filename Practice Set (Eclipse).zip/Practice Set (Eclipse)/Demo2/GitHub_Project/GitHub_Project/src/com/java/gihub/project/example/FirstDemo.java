package com.java.gihub.project.example;

import java.util.HashMap;
import java.util.TreeSet;

public class FirstDemo {

	public static void main(String[] args) {
		
		HashMap hashmap= new HashMap();
		hashmap.put("Swapnil", 75);
		hashmap.put("Raj", 80);
		hashmap.put("Gopal", 92);
		hashmap.put("Anil", 84);
		
		System.out.println(hashmap);
		

	}

}
