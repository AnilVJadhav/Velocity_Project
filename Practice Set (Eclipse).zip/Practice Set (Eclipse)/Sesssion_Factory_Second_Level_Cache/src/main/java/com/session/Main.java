package com.session;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		//Step-1 Create Configuration Object
		Configuration configuration= new Configuration();
					
		//Step-2 Configure the Configuration
	    configuration.configure("hibernate.cfg.xml");
	    
		//Step-3 Create SessionFactory Object
		SessionFactory sf= configuration.buildSessionFactory();
				
		//Step-4 Create Object Of Session
	    Session session =sf.openSession();
	    
	    //Fetch Data From DB
	   Student student= session.get(Student.class, 1);
	   System.out.println("Student ID is :"+student.getId());
	   System.out.println("Student City is :"+student.getCity());;
	   System.out.println("Student Mobile Number is:"+student.getMobile());
	   System.out.println("Student Name is :"+student.getName());
	    
	   System.out.println("**********************************************");
	   
	   //Fetch Another Student Info. from DB
	     Student student2 = session.get(Student.class ,2);
	     System.out.println("Student ID is :"+student2.getId());
	     System.out.println("Student City is :"+student2.getCity());
	     System.out.println("Student Mobile Number is:"+student2.getMobile());
	     System.out.println("Student Name is: "+student2.getName());
	     
	  
	}

}
