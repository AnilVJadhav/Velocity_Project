package com.example;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		
		Configuration cfg=getConfiguration();
		SessionFactory sf= cfg.buildSessionFactory();
		Session session=sf.openSession();
		Transaction transaction =session.beginTransaction();
		
		User user= new User();
		
		Policy policy = new Policy("A1", "car insurance", "Active",user);
		Policy policy1 = new Policy("A2", "Life insurance", "Active",user);
		user.setName("Anil");
		user.setEmail("anil123@gmail.com");
		
		Set <Policy>set= new HashSet<Policy>();	
		set.add(policy);
		set.add(policy1);
		
		user.setPolicy(set);
		
		session.save(user);
		session.save(policy);
		session.save(policy1);
		
		transaction.commit();
		session.close();
		sf.close();
  
	}
    //create method which return Configuration
	public static  Configuration getConfiguration() {
		
		Configuration cfg= new Configuration();
		cfg.configure("hibernate.cfg.xml");
		return cfg;
	}
}
