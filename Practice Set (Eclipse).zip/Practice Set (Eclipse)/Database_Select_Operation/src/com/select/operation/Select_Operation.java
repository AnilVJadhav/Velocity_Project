package com.select.operation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Select_Operation {

         public static void main(String[] args) {
				
				//Loading Class
				try {
					Class.forName("com.mysql.jdbc.Driver");
					
					//Creating Connection
				Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/example", "root", "Anilj@1998");
				//create statement
				PreparedStatement preparedStatement =connection.prepareStatement("select * from employee");
				
				//execute query
				ResultSet rs=preparedStatement.executeQuery();
				
				while(rs.next()) {
					
					System.out.println("Id :"+rs.getInt(1));
					System.out.println("lastName: "+rs.getString(2));
					System.out.println("FirstName:"+rs.getString(3));
					System.out.println("city :"+rs.getString(4));
					System.out.println("salary :"+rs.getInt(5));
					
				}
				//closing 
				connection.close();
				preparedStatement.close();
				rs.close();
				
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
}