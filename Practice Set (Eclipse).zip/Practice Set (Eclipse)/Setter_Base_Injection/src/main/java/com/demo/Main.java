package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		//Create ApplicationContext Object
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml ");
		
		//Calling getBean method
		Student student =(Student) applicationContext.getBean("j");
		System.out.println("Details of  "+student);
		student.getMessage("Anil, How are you...!");
	}

}
