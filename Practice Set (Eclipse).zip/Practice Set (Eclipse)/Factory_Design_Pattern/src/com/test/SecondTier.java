package com.test;

public class SecondTier implements Booking{

	@Override
	public String getACClassSeats() {
		return "Second Class AC seat availability= 10";
	}
   
	
}
