package com.test;

public class FirstTier implements Booking {

	@Override
	public String getACClassSeats() {
		return "First Class AC seats Available= 10";
	}

}
