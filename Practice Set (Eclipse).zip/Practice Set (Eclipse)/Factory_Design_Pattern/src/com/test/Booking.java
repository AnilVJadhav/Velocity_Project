package com.test;

public interface Booking {
	
	  public String getACClassSeats();
}
