package com.test;

public class ThirdTier implements Booking {

	@Override
	public String getACClassSeats() {
		return "Third Class AC seats avilabile= 5";
	}

}
