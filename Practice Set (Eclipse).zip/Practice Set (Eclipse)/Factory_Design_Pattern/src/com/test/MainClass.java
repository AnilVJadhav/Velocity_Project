package com.test;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
        System.out.println("Enter the available AC seats :");
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        Booking b =BookinFactory.createBooking(s);
        System.out.println(b.getACClassSeats());        

	}

}
