package com.demo.Optional_Class;

import java.util.Optional;

public class Example_3 {

	public static void main(String[] args) {
		
		String [] str=new String[10];
		/*String lowercase = str[5].toLowerCase();
		System.out.println(lowercase);*/
		
		
		Optional<String>checkNull = Optional.ofNullable(str[5]);
		if(checkNull.isPresent()) {
			String lowercase1 = str[5].toLowerCase();
			System.out.println("lowerCase is :"+lowercase1);
			
		}else {
			
			System.out.println("LowerCase is not present");
		}

	}

}
