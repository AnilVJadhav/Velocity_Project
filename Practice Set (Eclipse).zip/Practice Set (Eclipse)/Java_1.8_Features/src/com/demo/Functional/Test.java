package com.demo.Functional;

@FunctionalInterface
public interface Test {
	
	void getStudentName(String name);

}
