package com.demo.Functional;

public class Main implements Test {

	public static void main(String[] args) {
		Main main= new Main();
		main.getStudentName("Anil");
	}

	@Override
	public void getStudentName(String name) {
		System.out.println("Student name is :"+name);
	}

}
