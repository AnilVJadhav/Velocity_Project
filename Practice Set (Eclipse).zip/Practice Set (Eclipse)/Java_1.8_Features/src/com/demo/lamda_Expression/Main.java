package com.demo.lamda_Expression;

public class Main  {

	public static void main(String[] args) {
		// new Approach
		Addition addition= (p,q)->(p+q);
		
     Addition addition1 = (p,q)->{
			
		     System.out.println("First Variable value is :"+p);
			 System.out.println("Second Variable Value is:"+q);
		     System.out.println("Addition of two variable is:"+(p+q));
		     return p;		              
		};
	}
}