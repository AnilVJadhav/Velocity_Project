package com.demo.lamda_Expression;

public interface Addition {
	
	int add(int a ,int b);

}
