package com.demo.String_Joiner;

import java.util.StringJoiner;

public class Example_4 {

	public static void main(String[] args) {

		StringJoiner stringJoiner= new StringJoiner ("-");
		stringJoiner.add("Anil");
		stringJoiner.add("Pawan");
		stringJoiner.add("Rahul");
		stringJoiner.add("Azher");
		System.out.println(stringJoiner);
	}

}
