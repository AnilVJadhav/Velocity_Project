package com.demo.static_method;

public interface Example_2 {
	
	static void x1() {
		
		System.out.println("This is the Static method");
	}

}
