package com.demo.static_method;

public class Main {

	public static void main(String[] args) {
		Example_2.x1();
	}

}
