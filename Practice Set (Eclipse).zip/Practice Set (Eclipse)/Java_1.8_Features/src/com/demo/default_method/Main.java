package com.demo.default_method;

public class Main implements Example{

	public static void main(String[] args) {
		Main main= new Main();
		main.m1();
	}

}
