package com.demo.default_method;

public interface Example {
	
	default void m1(){
                 
		System.out.println("This is default method");
	}

}
