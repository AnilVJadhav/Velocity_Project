package com.demo.Stream_api;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		
		//Creating a String
		List<Integer>list= Arrays.asList(2,3,5,6,4,8,7,4,9,20);
		
        //Count the Even Number
		long no= list.stream().filter(n->n%2==0).count();
		System.out.println("Even num are :"+no);
		
		long no1= list.stream().filter(n->n%2!=0).count();
		System.out.println("Odd numbers are :"+no1);
		list.forEach(n->System.out.println(n));
		
		Map <String ,String>map= new HashMap<>();
		map.put("Anil", "Jadhav");
		map.put("Ajay", "Gosavi");
		map.put("Puja", "Lad");
		map.put("Jagruti", "Patil");
		
		map.forEach((a,b)->System.out.println("Key : "+a+" , "+" Value :"+b));
		String name=map.toString().toLowerCase();
		System.out.println(name);
		
	}

}
