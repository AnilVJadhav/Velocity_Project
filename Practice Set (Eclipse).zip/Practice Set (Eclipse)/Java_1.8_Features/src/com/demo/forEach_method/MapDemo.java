package com.demo.forEach_method;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {
	

	public static void main(String[] args) {
         
		Map<String,String>map = new HashMap<String, String>();
		map.put("10", "Ram");
		map.put("20", "Rohan");
		map.put("30", "Rihan");
		map.put("40", "Roshan");
		
		//Old Approach
		Set<String> s= map.keySet();
		for(String s1 : s) {
			
			System.out.println("Key :"+s1);
			System.out.println("Value :"+map.get(s1));
			
		}
		//New Approach
		map.forEach((k,v)->System.out.println("Key= "+k+" "+"Value= "+v));
	}

}
