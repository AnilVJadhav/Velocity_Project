package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		
		//Step-1 Create Object of Configuration 
		Configuration cfg= new Configuration();
		
		//Step-2 Configure
		cfg.configure("hibernate.cfg.xml");
		
		//Step-3 Create Object Of SessionFactory
		SessionFactory  sf =cfg.buildSessionFactory();
		
		//Step-4 Create Object of Session
		Session session =sf.openSession();
		
		//Step-5 Create Object of Transaction
		Transaction tr=session.beginTransaction();
		
		//set value of Empoyee
		
		Employee emp= new Employee();
		emp.setName("Anil");
		emp.setCity("Udgir");
		emp.setMobile("9075269414");
		
		//inserting Object to DB
		session.save(emp);
		System.out.println("Data Inserted Successfully....");
		
		tr.commit();
		session.close();
	}
}
