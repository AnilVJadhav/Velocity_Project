package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Required;

public class Driver {
	
	public String Driver;
	public String url;
	public String username;
	public String password;
	
	
	public String getDriver() {
		return Driver;
	}
      @Required
	public void setDriver(String driver) {
		Driver = driver;
	}
	public String getUrl() {
		return url;
	}
	@Required
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Driver [Driver=" + Driver + ", url=" + url + ", username=" + username + ", password=" + password + "]";
	}
	
     public void getConnection() throws ClassNotFoundException, SQLException {
    	 
    	 Class.forName(Driver);
    	 Connection con=DriverManager.getConnection(url, username, password);
    	 System.out.println("Connection is"+con);
     }
}
