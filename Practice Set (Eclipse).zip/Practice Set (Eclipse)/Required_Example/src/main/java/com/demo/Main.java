package com.demo;

import java.sql.SQLException;


public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//Create the Object Of AppplicationContext
		ApplicationContext context=new ClassPathXmlApplicationContext("Required.xml");
		Driver driver=(Driver) context.getBean("a");
		System.out.println("Driver Object is" +driver);
		driver.getConnection(); 

	}

}
