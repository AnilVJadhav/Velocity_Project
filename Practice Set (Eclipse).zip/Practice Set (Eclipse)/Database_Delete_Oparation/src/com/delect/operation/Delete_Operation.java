package com.delect.operation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delete_Operation {

	static Connection connection;
		static PreparedStatement preparedStatement;
		public static void main(String[] args) {
			
			
		try {
			//Create Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish DriverManger with connection
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/example", "root", "Anilj@1998");
			PreparedStatement preparedStatement =connection.prepareStatement("Delete from employee where id=?");
			preparedStatement.setInt(1, 2);
			int no=preparedStatement.executeUpdate();
			System.out.println("Record deleted.."+no);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//closing statement
			
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
