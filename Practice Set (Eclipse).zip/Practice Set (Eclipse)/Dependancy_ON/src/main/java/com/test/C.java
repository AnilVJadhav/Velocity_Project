package com.test;

public class C {
	
	public C() {
		System.out.println("This is C object");
	}

}
