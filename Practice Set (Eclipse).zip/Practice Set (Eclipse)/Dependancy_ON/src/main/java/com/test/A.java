package com.test;

public class A {
	
	public A() {
		System.out.println("this is A object ");
	}

}
