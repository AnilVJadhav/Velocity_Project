package com.test;

public class B {
	
	public B() {
		
		System.out.println("This is B object");
		
	}

}
