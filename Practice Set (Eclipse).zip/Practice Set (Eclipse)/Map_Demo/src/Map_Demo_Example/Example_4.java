package Map_Demo_Example;

import java.util.TreeMap;

public class Example_4 {
	public static void main(String[] args) {
		
		TreeMap treemap= new TreeMap();
		treemap.put(12, "Ram");
		treemap.put(15, "Anamika");
		treemap.put(12, "Yash");
		treemap.put(9, null);
		
		System.out.println("treemap is having "+treemap);
		
		
	}
	
	

}
