package Map_Demo_Example;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class Example_2 {

	public static void main(String[] args) {
		
     	Hashtable<Integer,String> hashtable= new Hashtable<Integer, String>();
     	hashtable.put(10, "Monday");
     	hashtable.put(20, "Tuesaday");
     	hashtable.put(30, "Friday");
     	hashtable.put(40, "Saturday");
     	
     	// we have take keys using for each loop
     	
        Set<Integer>keys=hashtable.keySet();
        
        for(int i: keys) {
        	System.out.println("keys of hashtable are :"+i);
        	System.out.println("Vlues of hashtable are:" +hashtable.get(keys));
        }
        
     	System.out.println(hashtable.get(20));
     	System.out.println("*************************");
     	
         Iterator<Integer> itr=keys.iterator();
         while(itr.hasNext()) {
        	 System.out.println("Keys of Hashtable are :" +itr.next());
        	 System.out.println("values of Hashtable are"+ hashtable.get(itr));
         }

	}

}
