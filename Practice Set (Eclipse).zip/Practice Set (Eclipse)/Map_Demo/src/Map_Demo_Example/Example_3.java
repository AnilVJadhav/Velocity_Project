package Map_Demo_Example;

import java.util.LinkedHashMap;

public class Example_3 {

	public static void main(String[] args) {
		
		LinkedHashMap linkedhashmap= new LinkedHashMap();
		linkedhashmap.put(10, "A");
		linkedhashmap.put(20, "B");
		linkedhashmap.put(30, "C");
		linkedhashmap.put(null, "D");
		linkedhashmap.put(40, null);
		
		System.out.println("linkedhashmap are :"+linkedhashmap);
		
		linkedhashmap.forEach((p,q) ->System.out.println (p+ " " +q));
		
		

	}

}
