package Map_Demo_Example;

import java.util.Hashtable;
import java.util.Map;

public class Example_1 {

	public static void main(String[] args) {
		
		Hashtable hashtable= new Hashtable();
		hashtable.put(10, "Ram");
		hashtable.put(12, "Shyam");
		hashtable.put(20, "Shital");
		
		System.out.println("hashtable contains:" +hashtable);
		
		
		Map map= new Hashtable();
		map.put("First", "Ram");
		map.put("Second", "Shyam");
		map.put(null, "Anamika");
		map.put("Third", null);
		
		System.out.println("Map contains :"+map);

	}

}
