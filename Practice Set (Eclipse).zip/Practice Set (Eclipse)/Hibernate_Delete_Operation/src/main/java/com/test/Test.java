package com.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
         // Create Object of Configuration
	     Configuration configuration= new Configuration();
	     
	     //Call Configure method
	     configuration.configure("hibernate.cfg.xml");
	     
	     //Create Object Of SessionFactory
	   SessionFactory sf= configuration.buildSessionFactory();
	     
		//Create Object of Session
	     Session session = sf.openSession();
	     
	     //Create Transaction Object
	     Transaction transaction = session.beginTransaction();
	     
	     //Fetching the Data from student on id
	     Student student=session.get(Student.class, 3);
	     
	     System.out.println("Student id is: "+student.getId());
	     System.out.println("Student name is :"+student.getName());
	     
	     session.delete(student);
	     transaction.commit();
	     System.out.println("Record deleted successfully...");
	     
	     session.close();
	     sf.close();
	}

}
